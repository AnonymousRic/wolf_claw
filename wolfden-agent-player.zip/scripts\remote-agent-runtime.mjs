import { spawn } from 'node:child_process';
import process from 'node:process';
import {
  DEFAULT_AGENT_RUNTIME_ID,
  DEFAULT_AGENT_THINKING,
} from './common.mjs';

const REMOTE_AGENT_MAX_SPEECH_SEGMENT_CHARS = 200;
const REMOTE_AGENT_MAX_SPEECH_SEGMENTS = 3;
const REMOTE_AGENT_MAX_SPEECH_CHARS = 602;
const REMOTE_AGENT_MAX_PLATFORM_TIMEOUT_MS = 30_000;
const SPEECH_PHASES = new Set(['sheriff_speech', 'day_speech', 'day_pk_speech', 'last_words']);
const COMPACT_DECISION_PHASES = new Set(['day_vote', 'day_pk_vote', 'sheriff_vote', 'sheriff_direction', 'sheriff_transfer']);
const SPEECH_PROMPT_LIMITS = {
  deathTimeline: 3,
  sheriffTimeline: 3,
  voteTimeline: 4,
  speechTimeline: 6,
  recentPublicEvents: 4,
};
const DECISION_PROMPT_LIMITS = {
  deathTimeline: 3,
  sheriffTimeline: 3,
  voteTimeline: 4,
  speechTimeline: 4,
  recentPublicEvents: 4,
};
const REFERENCE_LIMITS = {
  core: 400,
  role: 500,
  phase: 900,
};

function getPromptTrimLimits(phase) {
  if (SPEECH_PHASES.has(phase)) {
    return SPEECH_PROMPT_LIMITS;
  }

  if (COMPACT_DECISION_PHASES.has(phase)) {
    return DECISION_PROMPT_LIMITS;
  }

  return null;
}

function shouldOmitPhaseReference(phase) {
  return SPEECH_PHASES.has(phase) || COMPACT_DECISION_PHASES.has(phase);
}

const LEGACY_SPEECH_HISTORY_LIMITS = {
  deathTimeline: 4,
  sheriffTimeline: 4,
  voteTimeline: 6,
  speechTimeline: 8,
};
const compatRejectedParamKeys = new Set();

export function __resetRemoteAgentCompatCacheForTests() {
  compatRejectedParamKeys.clear();
}

function compactText(text) {
  return String(text ?? '').replace(/\s+/g, ' ').trim();
}

function normalizePositiveInteger(value, fallback) {
  return Number.isFinite(value) && value > 0 ? Math.floor(value) : fallback;
}

function resolveSpeechBudget(legalAction, responseSchema = null) {
  const schemaMaxSegments = normalizePositiveInteger(
    responseSchema?.maxSpeechSegments,
    REMOTE_AGENT_MAX_SPEECH_SEGMENTS,
  );
  const schemaMaxSegmentChars = normalizePositiveInteger(
    responseSchema?.maxSpeechSegmentChars,
    REMOTE_AGENT_MAX_SPEECH_SEGMENT_CHARS,
  );
  const schemaMaxSpeechChars = normalizePositiveInteger(
    responseSchema?.maxSpeechChars,
    REMOTE_AGENT_MAX_SPEECH_CHARS,
  );
  const legalMaxSpeechChars = normalizePositiveInteger(
    legalAction?.maxTextLength,
    schemaMaxSpeechChars,
  );

  return {
    maxSpeechSegments: Math.min(REMOTE_AGENT_MAX_SPEECH_SEGMENTS, schemaMaxSegments),
    maxSpeechSegmentChars: Math.min(REMOTE_AGENT_MAX_SPEECH_SEGMENT_CHARS, schemaMaxSegmentChars),
    maxSpeechChars: Math.min(REMOTE_AGENT_MAX_SPEECH_CHARS, schemaMaxSpeechChars, legalMaxSpeechChars),
  };
}

function splitSpeechIntoLines(text) {
  return String(text ?? '')
    .split(/\r?\n+/)
    .map((segment) => compactText(segment))
    .filter(Boolean);
}

function wrapSpeechSegment(segment, maxSegmentChars) {
  const normalized = compactText(segment);
  if (!normalized) {
    return [];
  }

  const chunks = [];
  for (let index = 0; index < normalized.length; index += maxSegmentChars) {
    chunks.push(normalized.slice(index, index + maxSegmentChars));
  }
  return chunks;
}

function normalizeSpeechSegments(rawSegments, speechBudget) {
  const normalizedSegments = [];
  let totalChars = 0;

  for (const rawSegment of rawSegments) {
    const wrappedSegments = wrapSpeechSegment(rawSegment, speechBudget.maxSpeechSegmentChars);
    for (const wrappedSegment of wrappedSegments) {
      if (normalizedSegments.length >= speechBudget.maxSpeechSegments) {
        break;
      }

      const separatorChars = totalChars > 0 ? 1 : 0;
      const remainingChars = speechBudget.maxSpeechChars - totalChars - separatorChars;
      if (remainingChars <= 0) {
        break;
      }

      const chunk = wrappedSegment.slice(0, Math.min(speechBudget.maxSpeechSegmentChars, remainingChars));
      if (!chunk) {
        break;
      }

      normalizedSegments.push(chunk);
      totalChars += separatorChars + chunk.length;

      if (chunk.length < wrappedSegment.length) {
        break;
      }
    }

    if (normalizedSegments.length >= speechBudget.maxSpeechSegments || totalChars >= speechBudget.maxSpeechChars) {
      break;
    }
  }

  const fullText = normalizedSegments.join('\n');
  return {
    segments: normalizedSegments,
    fullText,
    charCount: fullText.length,
  };
}

function resolvePhaseReferenceKey(phase) {
  if (!phase) {
    return 'day';
  }
  if (phase.startsWith('night')) {
    return 'night';
  }
  if (phase.startsWith('sheriff')) {
    return 'sheriff';
  }
  if (phase === 'last_words') {
    return 'last-words';
  }
  if (phase === 'finished') {
    return 'result';
  }
  return 'day';
}

function trimReferenceContent(content, maxLength = 900) {
  const normalized = String(content ?? '').trim();
  if (!normalized) {
    return '';
  }
  return normalized.length <= maxLength
    ? normalized
    : `${normalized.slice(0, maxLength - 3)}...`;
}

function buildReferenceSummary(referenceBundle, role, phase) {
  const roleDocument = referenceBundle?.roleDocuments?.[role]
    ?? referenceBundle?.roleDocuments?.villager
    ?? null;
  const phaseDocument = shouldOmitPhaseReference(phase)
    ? null
    : referenceBundle?.phaseDocuments?.[resolvePhaseReferenceKey(phase)]
      ?? referenceBundle?.phaseDocuments?.day
      ?? null;

  return {
    core: Array.isArray(referenceBundle?.coreDocuments)
      ? referenceBundle.coreDocuments.map((document) => ({
          path: document.path,
          content: trimReferenceContent(document.content, REFERENCE_LIMITS.core),
        }))
      : [],
    role: roleDocument
      ? {
          path: roleDocument.path,
          content: trimReferenceContent(roleDocument.content, REFERENCE_LIMITS.role),
        }
      : null,
    phase: phaseDocument
      ? {
          path: phaseDocument.path,
          content: trimReferenceContent(phaseDocument.content, REFERENCE_LIMITS.phase),
        }
      : null,
  };
}

function buildSpeechPromptRules(payload) {
  const responseSchema = payload?.decisionContext?.responseSchema ?? null;
  const legalActions = Array.isArray(payload?.legalActions)
    ? payload.legalActions
    : Array.isArray(payload?.decisionContext?.decisionRequest?.legalActions)
      ? payload.decisionContext.decisionRequest.legalActions
      : [];
  const speechAction = legalActions.find((action) => (
    action?.actionType === 'speech' || (action?.minTextLength ?? 0) > 0
  )) ?? null;
  const speechBudget = resolveSpeechBudget(speechAction, responseSchema);

  return [
    'If the chosen legal action requires speech, include speech.segments and speech.charCount.',
    'If the chosen legal action does not require speech, omit speech.',
    `If speech is present, use at most ${speechBudget.maxSpeechSegments} segments.`,
    `Each speech segment must be at most ${speechBudget.maxSpeechSegmentChars} characters.`,
    `The joined speech text must be at most ${speechBudget.maxSpeechChars} characters.`,
    'speech.charCount must equal speech.segments.join("\\n").length exactly.',
    'Prefer 1-2 segments. Only use the 3rd segment when necessary.',
  ];
}

function buildSharedPromptBody({ payload, role, phase }) {
  return [
    'You are operating exactly one WolfDen player seat through remote agent.',
    'Return exactly one JSON object and nothing else.',
    'Never output markdown, code fences, or explanatory prose outside the JSON object.',
    'Only choose an actionType that exists in legalActions.',
    'Only choose targets from allowedTargetIds, and satisfy min/max target counts.',
    ...buildSpeechPromptRules(payload),
    'reasoningSummary must be short and should explain the role/phase logic behind the action.',
    `Current role: ${role || 'unknown'}. Current phase: ${phase || 'unknown'}.`,
    'Output schema:',
    '{"actionType":"string","targetPlayerId":"string|null","targetPlayerIds":["string"]|null,"speech":{"segments":["string"],"charCount":0},"reasoningSummary":"string"}',
    'Decision payload:',
    JSON.stringify(payload),
  ].join('\n');
}

function trimDigestEntries(entries, limit) {
  return Array.isArray(entries)
    ? entries.slice(-limit)
    : [];
}

export function __trimMirrorPublicContextForTests(publicContext, phase) {
  if (!publicContext || typeof publicContext !== 'object') {
    return publicContext ?? null;
  }

  const limits = getPromptTrimLimits(phase);
  if (!limits) {
    return publicContext;
  }

  const backgroundDigest = publicContext.backgroundDigest && typeof publicContext.backgroundDigest === 'object'
    ? publicContext.backgroundDigest
    : {};
  const historyDigest = publicContext.historyDigest && typeof publicContext.historyDigest === 'object'
    ? publicContext.historyDigest
    : {};

  return {
    ...publicContext,
    backgroundDigest: {
      ...backgroundDigest,
      recentPublicEvents: trimDigestEntries(backgroundDigest.recentPublicEvents, limits.recentPublicEvents),
    },
    historyDigest: {
      ...historyDigest,
      deathTimeline: trimDigestEntries(historyDigest.deathTimeline, limits.deathTimeline),
      sheriffTimeline: trimDigestEntries(historyDigest.sheriffTimeline, limits.sheriffTimeline),
      voteTimeline: trimDigestEntries(historyDigest.voteTimeline, limits.voteTimeline),
      speechTimeline: trimDigestEntries(historyDigest.speechTimeline, limits.speechTimeline),
    },
  };
}

function buildMirrorPrompt(planRequest, referenceBundle) {
  const trimmedPublicContext = __trimMirrorPublicContextForTests(planRequest.publicContext, planRequest.phase);
  const payload = {
    matchId: planRequest.matchId,
    playerId: planRequest.playerId,
    phase: planRequest.phase,
    deadlineMs: planRequest.deadlineMs,
    legalActions: planRequest.legalActions,
    privateState: planRequest.privateState,
    publicContext: {
      matchId: trimmedPublicContext?.backgroundDigest?.matchId ?? planRequest.matchId,
      day: trimmedPublicContext?.day ?? null,
      turn: trimmedPublicContext?.turn ?? null,
      scoreboard: trimmedPublicContext?.scoreboard ?? null,
      tableState: trimmedPublicContext?.tableState ?? null,
      backgroundDigest: trimmedPublicContext?.backgroundDigest ?? null,
      historyDigest: trimmedPublicContext?.historyDigest ?? null,
    },
    decisionContext: planRequest.decisionContext,
    references: buildReferenceSummary(
      referenceBundle,
      planRequest.privateState?.role ?? planRequest.decisionContext?.identity?.role,
      planRequest.phase,
    ),
  };

  return buildSharedPromptBody({
    payload,
    role: planRequest.privateState?.role ?? planRequest.decisionContext?.identity?.role,
    phase: planRequest.phase,
  });
}

function buildSeatPrompt(turn, referenceBundle) {
  const payload = {
    matchId: turn.matchId,
    playerId: turn.playerId,
    phase: turn.phase,
    deadlineAt: turn.phaseDeadlineAt ?? null,
    legalActions: turn.legalActions ?? [],
    privateState: turn.privateState ?? null,
    visibleHistory: turn.events ?? [],
    objectiveText: turn.objectiveText ?? '',
    references: buildReferenceSummary(referenceBundle, turn.privateState?.role, turn.phase),
  };

  return buildSharedPromptBody({
    payload,
    role: turn.privateState?.role ?? 'unknown',
    phase: turn.phase,
  });
}

function parseExtraArgs(raw) {
  if (!raw) {
    return [];
  }
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.every((item) => typeof item === 'string')) {
      return parsed;
    }
  } catch {
    // Fall through to the whitespace split below for local debugging convenience.
  }

  return raw
    .split(/\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

function resolveRemoteAgentCommand() {
  if (!process.env.WOLFDEN_AGENT_BIN) {
    throw new Error('No local agent runtime command configured. Set WOLFDEN_AGENT_BIN for this host or use the host native tools described in the WolfDen Agent Guide.');
  }
  return {
    bin: process.env.WOLFDEN_AGENT_BIN,
    extraArgs: parseExtraArgs(process.env.WOLFDEN_AGENT_BIN_ARGS),
  };
}

function resolveLocalTimeoutSeconds(config, deadlineMs, fallbackMs = 12_000) {
  if (Number.isFinite(deadlineMs) && deadlineMs > 0) {
    const boundedPlatformBudgetMs = Math.max(
      2_000,
      Math.min(deadlineMs - 1_000, REMOTE_AGENT_MAX_PLATFORM_TIMEOUT_MS),
    );
    return Math.max(2, Math.ceil(boundedPlatformBudgetMs / 1000));
  }

  const configuredTimeoutMs = Number.isFinite(config?.runtimeTimeoutSeconds) && config.runtimeTimeoutSeconds > 0
    ? config.runtimeTimeoutSeconds * 1000
    : fallbackMs;
  const boundedMs = Math.max(2_000, Math.min(configuredTimeoutMs, REMOTE_AGENT_MAX_PLATFORM_TIMEOUT_MS));
  return Math.max(2, Math.ceil(boundedMs / 1000));
}

function buildSessionKey(config, remoteAgentParticipantId, matchId, playerId) {
  return `wolfden:${remoteAgentParticipantId}:${matchId}:${playerId}`;
}

function buildHealthcheckSessionKey(config, agentName) {
  return `wolfden:health:${agentName || 'unknown-agent'}`;
}

function callRemoteAgentGateway(params, timeoutSeconds) {
  const command = resolveRemoteAgentCommand();
  const args = [
    ...command.extraArgs,
    'gateway',
    'call',
    'agent',
    '--params',
    JSON.stringify(params),
    '--expect-final',
    '--json',
  ];

  if (process.env.WOLFDEN_REMOTE_AGENT_GATEWAY_URL) {
    args.push('--url', process.env.WOLFDEN_REMOTE_AGENT_GATEWAY_URL);
  }
  if (process.env.WOLFDEN_REMOTE_AGENT_GATEWAY_TOKEN) {
    args.push('--token', process.env.WOLFDEN_REMOTE_AGENT_GATEWAY_TOKEN);
  }
  if (process.env.WOLFDEN_AGENT_GATEWAY_PASSWORD) {
    args.push('--password', process.env.WOLFDEN_AGENT_GATEWAY_PASSWORD);
  }

  return new Promise((resolve, reject) => {
    const child = spawn(command.bin, args, {
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, Math.max(2_000, timeoutSeconds * 1000 + 1000));

    child.stdout.on('data', (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on('data', (chunk) => {
      stderr += String(chunk);
    });
    child.on('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (timedOut) {
        reject(new Error('remote agent run timed out.'));
        return;
      }
      if (code !== 0) {
        reject(new Error(`remote agent gateway call failed with exit code ${code}: ${stderr.trim() || stdout.trim() || 'no output'}`));
        return;
      }
      resolve({
        stdout: stdout.trim(),
        stderr: stderr.trim(),
      });
    });
  });
}

function sanitizeIdempotencyPart(value, fallback = 'unknown') {
  const normalized = compactText(value ?? fallback).replace(/[^a-zA-Z0-9:_-]/g, '-');
  return normalized || fallback;
}

function buildIdempotencyKey(...parts) {
  return parts.map((part, index) => sanitizeIdempotencyPart(part, `part-${index + 1}`)).join(':');
}

function buildAgentParams({ config, prompt, sessionKey, idempotencyKey }) {
  const params = {
    message: prompt,
    sessionKey,
    deliver: false,
    thinking: config?.runtimeThinking || DEFAULT_AGENT_THINKING,
  };
  if (!compatRejectedParamKeys.has('agentId')) {
    params.agentId = config?.runtimeAgentId || DEFAULT_AGENT_RUNTIME_ID;
  }
  if (!compatRejectedParamKeys.has('idempotencyKey')) {
    params.idempotencyKey = idempotencyKey;
  }
  return params;
}

function resolveCompatDowngradeKeys(error) {
  const message = error instanceof Error ? error.message : String(error);
  const lowered = message.toLowerCase();
  const rejectedKeys = [];

  if (lowered.includes('idempotencykey') || lowered.includes('idempotency key')) {
    rejectedKeys.push('idempotencyKey');
  }
  if (lowered.includes('agentid') || lowered.includes('agent id')) {
    rejectedKeys.push('agentId');
  }

  return rejectedKeys;
}

async function callRemoteAgentGatewayWithCompat(params, timeoutSeconds) {
  try {
    return await callRemoteAgentGateway(params, timeoutSeconds);
  } catch (error) {
    const rejectedKeys = resolveCompatDowngradeKeys(error);
    if (!rejectedKeys.length) {
      throw error;
    }

    const downgradedParams = { ...params };
    for (const key of rejectedKeys) {
      compatRejectedParamKeys.add(key);
      delete downgradedParams[key];
    }
    return callRemoteAgentGateway(downgradedParams, timeoutSeconds);
  }
}

function tryParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function extractJsonObjectFromText(text) {
  const trimmed = String(text ?? '').trim();
  if (!trimmed) {
    return null;
  }

  const direct = tryParseJson(trimmed);
  if (direct) {
    return direct;
  }

  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch?.[1]) {
    const fenced = tryParseJson(fenceMatch[1].trim());
    if (fenced) {
      return fenced;
    }
  }

  const firstBrace = trimmed.indexOf('{');
  const lastBrace = trimmed.lastIndexOf('}');
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    return tryParseJson(trimmed.slice(firstBrace, lastBrace + 1));
  }

  return null;
}

function findNestedObject(value, predicate, visited = new Set()) {
  if (value == null) {
    return null;
  }

  if (typeof value === 'string') {
    const parsed = extractJsonObjectFromText(value);
    return parsed ? findNestedObject(parsed, predicate, visited) : null;
  }

  if (typeof value !== 'object') {
    return null;
  }

  if (visited.has(value)) {
    return null;
  }
  visited.add(value);

  if (predicate(value)) {
    return value;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      const match = findNestedObject(item, predicate, visited);
      if (match) {
        return match;
      }
    }
    return null;
  }

  for (const child of Object.values(value)) {
    const match = findNestedObject(child, predicate, visited);
    if (match) {
      return match;
    }
  }

  return null;
}

function parseRemoteAgentOutput(stdout, predicate) {
  const direct = extractJsonObjectFromText(stdout);
  if (direct) {
    return findNestedObject(direct, predicate);
  }

  const lines = String(stdout ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const parsed = extractJsonObjectFromText(lines[index]);
    if (!parsed) {
      continue;
    }
    const match = findNestedObject(parsed, predicate);
    if (match) {
      return match;
    }
  }

  return null;
}

function normalizeSpeech(decision, legalAction, responseSchema = null) {
  const requiresSpeech = (legalAction?.minTextLength ?? 0) > 0 || legalAction?.actionType === 'speech';
  const speechBudget = resolveSpeechBudget(legalAction, responseSchema);
  let rawSegments = [];

  if (decision?.speech && typeof decision.speech === 'object' && Array.isArray(decision.speech.segments)) {
    rawSegments = decision.speech.segments.flatMap((segment) => splitSpeechIntoLines(segment));
  } else if (typeof decision?.speech === 'string') {
    rawSegments = splitSpeechIntoLines(decision.speech);
  } else if (typeof decision?.text === 'string') {
    rawSegments = splitSpeechIntoLines(decision.text);
  }

  const normalizedSpeech = normalizeSpeechSegments(rawSegments, speechBudget);
  const { fullText } = normalizedSpeech;

  if (!requiresSpeech && !fullText) {
    return null;
  }

  if (requiresSpeech && !fullText) {
    throw new Error('remote agent returned no speech for a speech-required action.');
  }

  if (fullText.length < (legalAction?.minTextLength ?? 0)) {
    throw new Error('remote agent returned speech shorter than the required minimum.');
  }

  if (fullText.length > speechBudget.maxSpeechChars) {
    throw new Error('remote agent returned speech longer than the legal limit.');
  }

  return {
    segments: normalizedSpeech.segments,
    charCount: normalizedSpeech.charCount,
  };
}

export function __normalizeSpeechForTests(decision, legalAction, responseSchema = null) {
  return normalizeSpeech(decision, legalAction, responseSchema);
}

function normalizeTargets(decision, legalAction) {
  const targetIds = Array.from(new Set(
    Array.isArray(decision?.targetPlayerIds) && decision.targetPlayerIds.length > 0
      ? decision.targetPlayerIds
      : decision?.targetPlayerId
        ? [decision.targetPlayerId]
        : [],
  ));

  if (targetIds.length < (legalAction?.minTargetCount ?? 0)) {
    throw new Error('remote agent returned too few targets for the legal action.');
  }
  if (targetIds.length > (legalAction?.maxTargetCount ?? 1)) {
    throw new Error('remote agent returned too many targets for the legal action.');
  }
  if (!targetIds.every((targetId) => legalAction.allowedTargetIds.includes(targetId))) {
    throw new Error('remote agent returned an illegal target.');
  }

  if (targetIds.length === 0) {
    return {};
  }

  return legalAction.maxTargetCount > 1
    ? { targetPlayerIds: targetIds }
    : { targetPlayerId: targetIds[0] };
}

function normalizeDecision(decision, legalActions, responseSchema = null) {
  if (!decision || typeof decision !== 'object') {
    throw new Error('remote agent did not return a decision object.');
  }

  const legalAction = legalActions.find((action) => action.actionType === decision.actionType);
  if (!legalAction) {
    throw new Error(`remote agent returned an illegal actionType: ${decision.actionType ?? 'unknown'}`);
  }

  const normalized = {
    actionType: legalAction.actionType,
    ...normalizeTargets(decision, legalAction),
  };
  const speech = normalizeSpeech(decision, legalAction, responseSchema);
  if (speech) {
    normalized.speech = speech;
  }

  const reasoningSummary = compactText(
    decision.reasoningSummary
    ?? decision.reasoning
    ?? decision.summary
    ?? '',
  ).slice(0, 400);

  return {
    ...normalized,
    ...(reasoningSummary ? { reasoningSummary } : {}),
  };
}

async function runAgentPrompt({
  config,
  sessionKey,
  prompt,
  deadlineMs,
  idempotencyKey,
}) {
  const timeoutSeconds = resolveLocalTimeoutSeconds(config, deadlineMs);
  const params = buildAgentParams({
    config,
    prompt,
    sessionKey,
    idempotencyKey,
  });
  const startedAt = Date.now();
  const result = await callRemoteAgentGatewayWithCompat(params, timeoutSeconds);
  return {
    output: result.stdout,
    latencyMs: Date.now() - startedAt,
    timeoutSeconds,
  };
}

export async function checkRemoteAgentRuntimeHealth(config) {
  const timeoutSeconds = resolveLocalTimeoutSeconds(config, 8_000, 8_000);
  const sessionKey = buildHealthcheckSessionKey(config, config?.agentName);
  const params = buildAgentParams({
    config,
    prompt: 'Return exactly {"ok":true,"runtime":"remote-agent-loop"} and nothing else.',
    sessionKey,
    idempotencyKey: buildIdempotencyKey('wolfden-health', config?.agentName, Date.now()),
  });
  const startedAt = Date.now();

  try {
    const result = await callRemoteAgentGatewayWithCompat(params, timeoutSeconds);
    const payload = parseRemoteAgentOutput(result.stdout, (value) => value && value.ok === true);
    if (!payload || payload.ok !== true) {
      return {
        healthy: false,
        latencyMs: Date.now() - startedAt,
        detail: `remote agent loop returned an unexpected healthcheck payload: ${compactText(result.stdout).slice(0, 180) || 'empty output'}`,
      };
    }
    return {
      healthy: true,
      latencyMs: Date.now() - startedAt,
      detail: 'remote agent loop is reachable.',
    };
  } catch (error) {
    return {
      healthy: false,
      latencyMs: Date.now() - startedAt,
      detail: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function buildMirrorPlanFromRemoteAgent({
  config,
  remoteAgentParticipantId,
  planRequest,
  referenceBundle,
}) {
  const sessionKey = buildSessionKey(config, remoteAgentParticipantId, planRequest.matchId, planRequest.playerId);
  const prompt = buildMirrorPrompt(planRequest, referenceBundle);
  const promptChars = prompt.length;
  const result = await runAgentPrompt({
    config,
    remoteAgentParticipantId,
    sessionKey,
    prompt,
    deadlineMs: planRequest.deadlineMs ?? planRequest.decisionContext?.phase?.modelHardTimeoutMs ?? 12_000,
    idempotencyKey: buildIdempotencyKey('wolfden-plan', planRequest.requestId, planRequest.fingerprint),
  });
  const decision = normalizeDecision(
    parseRemoteAgentOutput(result.output, (value) => typeof value?.actionType === 'string'),
    planRequest.legalActions ?? [],
    planRequest.decisionContext?.responseSchema ?? null,
  );

  return {
    payload: {
      requestId: planRequest.requestId,
      fingerprint: planRequest.fingerprint,
      clientActionId: `wolfden-remote-agent-${Date.now()}`,
      ...decision,
    },
    latencyMs: result.latencyMs,
    requestId: planRequest.requestId,
    fingerprint: planRequest.fingerprint,
    deadlineMs: planRequest.deadlineMs ?? planRequest.decisionContext?.phase?.modelHardTimeoutMs ?? 12_000,
    promptChars,
    timeoutSeconds: result.timeoutSeconds,
  };
}

export async function buildSeatActionFromRemoteAgent({
  config,
  remoteAgentParticipantId,
  turn,
  referenceBundle,
}) {
  const sessionKey = buildSessionKey(config, remoteAgentParticipantId, turn.matchId, turn.playerId);
  const prompt = buildSeatPrompt(turn, referenceBundle);
  const deadlineMs = turn.phaseDeadlineAt
    ? Math.max(0, new Date(turn.phaseDeadlineAt).getTime() - Date.now())
    : 12_000;
  const result = await runAgentPrompt({
    config,
    sessionKey,
    prompt,
    deadlineMs,
    idempotencyKey: buildIdempotencyKey('wolfden-seat', turn.turnToken ?? turn.matchId, turn.playerId, turn.phase),
  });
  const decision = normalizeDecision(
    parseRemoteAgentOutput(result.output, (value) => typeof value?.actionType === 'string'),
    turn.legalActions ?? [],
    null,
  );

  return {
    action: {
      clientActionId: `wolfden-seat-${Date.now()}`,
      actionType: decision.actionType,
      ...(decision.targetPlayerIds?.length
        ? { targetPlayerIds: decision.targetPlayerIds }
        : decision.targetPlayerId
          ? { targetPlayerId: decision.targetPlayerId }
          : {}),
      ...(decision.speech ? { text: decision.speech.segments.join('\n') } : {}),
    },
    latencyMs: result.latencyMs,
  };
}
